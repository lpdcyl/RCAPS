# RCAPS 匿名实验结果材料

本包含 CPU 离散事件模拟得出的逐种子汇总表、审计后报告和可重建图表。真实性与来源哈希请对照内部 REBUILD_AUDIT.json；原始 JSON/日志与完整源码另行发布前需匿名审查。

P1-2 真机链路微基准与 P2-3 Sarathi 式计算侧 chunked-prefill 按用户范围跳过。任何容量失败均保留，不填零。

在含完整原始结果的仓库根目录，Windows gllm 环境中运行 python -m experiments.v6_completion.rebuild_all 可重新生成全部论文图表、表格和审计。
